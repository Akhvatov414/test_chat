<template>
    <h2>AppModal</h2>
</template>

<script>
    export default {
        name: "AppModal",
    }
</script>

<style scoped>

</style>
